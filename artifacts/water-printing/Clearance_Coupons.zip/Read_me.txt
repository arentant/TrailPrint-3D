Experimental TrailPrint clearance coupons
Print the matching Terrain and Water pair at each clearance without scaling.
Each coupon is 15 × 15 × 2 mm, with a 1 mm water insert. Clearances are per side.
Compare 0.10, 0.15 and 0.20 mm on your printer. Check dry fit, complete seat contact and remaining floor.
These files do not establish a validated fit; record your physical test results.
